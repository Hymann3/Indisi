cd core
cd tgc
python3 start.py
