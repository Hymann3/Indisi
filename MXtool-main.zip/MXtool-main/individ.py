import os
individ = input("""\033[32m[1]Дудос
[2]СМС бомбер
[3]Фишинг любого сайта
[4]Спамер тг
[5]Емаил спамер
[6]VK-BAN по токену
[7]Ссылка на профиль WhatsApp 
[8]Узнать реальный ip сайта
[9]Дополнительные кнопки для Termux
[10]Настройка алиасов
[11]Выкачать сайт
[12]Узнать зарегестрирован ли номер в телеграмм
Выберите параметр:""")
if individ == "1":
    os.system("clear")
    os.system("python3 core/DDOS.py")
elif individ == "2":
       os.system("clear") 
       os.system("python3 core/BOMBER.py")
elif individ == "3":
       os.system("clear")
       os.system("python3 core/PKGFISH.py")
elif individ == "4":
       os.system("clear")
       os.system("python3 core/TGSPAM.py")
elif individ == "5":
       os.system("clear")
       os.system("python3 core/EMAIL.py")
elif individ == "6":
       os.system("clear")
       os.system("python3 core/VK.py")
elif individ == "7":
       os.system("clear")
       os.system("python3 core/W.py")
elif individ == "8":
       os.system("clear")
       os.system("python3 core/cloud/IP.py")
elif individ == "9":
       os.system("clear")
       os.system ("bash knopki")
elif individ == "10":
       os.system("clear")
       os.system ("python3 core/alias/main.py")
elif individ == "11":
       os.system("clear")
       os.system ("python3 core/WT.py")
elif individ == "12":
       os.system("clear")
       os.system("bash core/tgc/start.sh")
else:
       os.system("individ")

